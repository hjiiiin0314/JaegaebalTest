package ksmart36.khj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootKhj1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootKhj1Application.class, args);
	}

}
