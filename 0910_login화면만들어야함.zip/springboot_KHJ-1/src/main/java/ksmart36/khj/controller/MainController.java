package ksmart36.khj.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MainController {

	@GetMapping("/")
	public String main() {
		
		return "index";
	}
	
	@GetMapping("/index2")
	public String main2() {
		
		return "index2";
	}
	
	@GetMapping("/login")
	public String login() {
		
		return "login";
	}
}
